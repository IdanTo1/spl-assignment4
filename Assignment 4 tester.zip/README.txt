HOW TO USE:
1. Unzip the entire archive in the assignment folder
2. Run "python3 tester.py" in a terminal window

If you run "python3 tester.py -v" the tester will also print the differences between the expected output and the actual output.
Every test folder has a small README with an explanation on the test