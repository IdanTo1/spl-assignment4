This test checks two suppliers supplying the same and one supplier supplying different products
Very similiar to the previous test, a little bigger though